pc.app.on("Map:Loaded", () => {
    try {
      window.modifyViewmodel = pc.app.root.findByName("WeaponPoint");
      modifyViewmodel.localPosition = { x: 0.55, y: 0.55, z: -0.56 };
      window.modifyWeapon = pc.app.root.findByName("WeaponCenter");
      modifyWeapon.localScale = { x: 1, y: 1, z: 1 };

        vlog("Viewmodel position successfully modified to the following values:\nX: " + modelPosX + "\nY: " + modelPosY + "\nZ: " + modelPosZ);
        vlog("Viewmodel scale successfully modified to the following values:\nX: " + modelScaleX + "\nY: " + modelScaleY + "\nZ: " + modelScaleZ);
    } catch (e) {
        vlog("Couldn't find viewmodel");
    }
});