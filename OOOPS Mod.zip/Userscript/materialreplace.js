pc.app.once('start', () => {

    // Changes Start Here
    pc.app.assets.find('Wall-Low-Shade-1').data.normalMap = null;

    pc.app.assets.find('Material').data.diffuseMapTint = false;
    pc.app.assets.find('Material.002').data.diffuseMapTint = false;

    pc.app.assets.find('Hallway-Low').data.ambient = [1, 1, 1];
    pc.app.assets.find('Hallway-Low').data.diffuseMapTint = false;

    pc.app.assets.find('Wall-Dungeon').data.emissive = [0, 0, 0];
    pc.app.assets.find('Wall-Dungeon').data.diffuse = [1, 1, 1];

    pc.app.assets.find('Xibalba-Cube').data.aoMap = null;
    pc.app.assets.find('Xibalba-Cube').data.normalMap = null;

    pc.app.assets.find('atlas_01_mat').data.diffuse = [1, 1, 1];

    pc.app.assets.find('atlas_01_mat').data.normalMap = null;
    pc.app.assets.find('atlas_01_mat').data.normalMap = null;
    pc.app.assets.find('atlas_01_mat').data.normalMap = null;
    pc.app.assets.find('atlas_01_mat').data.normalMap = null;

    // Weapon Materials
    pc.app.assets.find('Scar').data.shininess = 0;
    pc.app.assets.find('Scar').data.normalMap = null;

    pc.app.assets.find('HS_12').data.shininess = 0;
    pc.app.assets.find('HS_12').data.normalMap = null;

    pc.app.assets.find('Tec_1').data.shininess = 0;
    pc.app.assets.find('Tec_1').data.normalMap = null;

    pc.app.assets.find('Deagle').data.specular = [0, 0, 0];
    pc.app.assets.find('Deagle').data.shininess = 0;

    pc.app.assets.find('Dagger').data.emissiveMap = null;

    pc.app.assets.find('AK-47').data.shininess = 0;
    pc.app.assets.find('AK-47').data.normalMap = null;

    pc.app.assets.find('AWP').data.shininess = 0;
    pc.app.assets.find('AWP').data.normalMap = null;

    // Character Materials 
    pc.app.assets.find('Shin-Character').file.hash = "4c6828504c08d99283c97a189dedc924";
    pc.app.assets.find('Shin-Character').file.filename = "Shin-Model-Snowman.glb";
    pc.app.assets.find('Shin-Character').file.url = "files/assets/63113308/1/Shin-Model-Snowman.glb";

    pc.app.assets.find('Kulu-Default').data.diffuse = [1, 1, 1];

    console.log('Material Changes Complete')
})
